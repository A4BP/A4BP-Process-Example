This archive contains the source code for the BPEL examples in 
Chapters 10-11 of Essential Business Process Modeling (O'Reilly, 2005). 
The examples were tested in Oracle BPEL Process Manager, and developed 
in the Oracle BPEL plugin for Eclipse. Refer to the book for a description
of the code and the development environment.